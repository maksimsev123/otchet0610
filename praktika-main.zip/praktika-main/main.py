import sqlite3
import hashlib
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

# ==================== НАСТРОЙКИ СТИЛЯ ====================
BG_PRIMARY = "#FFFFFF"           
BG_SECONDARY = "#F8F9FA"        
BG_ACCENT = "#00FA9A"           
BG_HIGH_DISCOUNT = "#2E8B57"    
BG_HEADER = "#1B5E20"           
FG_WHITE = "#FFFFFF"            
FONT_FAMILY = "Segoe UI"
FONT_SIZE_NORMAL = 11
FONT_SIZE_TITLE = 18
FONT_SIZE_BUTTON = 10
CARD_BG = "#FFFFFF"

# Глобальные стили
def setup_styles():
    style = ttk.Style()
    style.theme_use('clam')
    
    style.configure("Treeview", font=(FONT_FAMILY, FONT_SIZE_NORMAL), rowheight=32, background=BG_PRIMARY, fieldbackground=BG_PRIMARY)
    style.configure("Treeview.Heading", font=(FONT_FAMILY, FONT_SIZE_NORMAL, "bold"), background=BG_HEADER, foreground=FG_WHITE)
    style.map("Treeview.Heading", background=[('active', BG_HIGH_DISCOUNT)])
    style.configure("TNotebook", background=BG_PRIMARY, tabposition='nw')
    style.configure("TNotebook.Tab", font=(FONT_FAMILY, FONT_SIZE_NORMAL), padding=[15, 6], background=BG_SECONDARY)
    style.map("TNotebook.Tab", background=[('selected', BG_ACCENT), ('active', BG_ACCENT)])
    style.configure("TButton", font=(FONT_FAMILY, FONT_SIZE_BUTTON), padding=8)
    style.configure("TLabel", font=(FONT_FAMILY, FONT_SIZE_NORMAL), background=BG_PRIMARY)

# Всплывающие подсказки
class ToolTip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tip_window = None
        widget.bind('<Enter>', self.show_tip)
        widget.bind('<Leave>', self.hide_tip)
    
    def show_tip(self, event=None):
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 25
        self.tip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        label = tk.Label(tw, text=self.text, justify=tk.LEFT,
                         background="#FFFFE0", relief=tk.SOLID, borderwidth=1,
                         font=(FONT_FAMILY, 9))
        label.pack()
    
    def hide_tip(self, event=None):
        if self.tip_window:
            self.tip_window.destroy()
            self.tip_window = None

# ==================== БАЗА ДАННЫХ ====================
def init_db():
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            login TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('customer', 'manager', 'admin')),
            full_name TEXT,
            email TEXT,
            phone TEXT,
            avatar TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS goods (
            good_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            size TEXT,
            price REAL NOT NULL,
            stock_quantity INTEGER NOT NULL DEFAULT 0,
            discount_percent INTEGER DEFAULT 0,
            category TEXT,
            image_emoji TEXT DEFAULT '👟',
            description TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS carts (
            cart_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cart_items (
            cart_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
            cart_id INTEGER NOT NULL,
            good_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 1,
            FOREIGN KEY (cart_id) REFERENCES carts(cart_id) ON DELETE CASCADE,
            FOREIGN KEY (good_id) REFERENCES goods(good_id) ON DELETE CASCADE,
            UNIQUE(cart_id, good_id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            order_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            total_amount REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'new',
            delivery_address TEXT,
            payment_method TEXT DEFAULT 'cash',
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    ''')
    
    cursor.execute('''
       
    ''')
    
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        admin_hash = hashlib.sha256("123".encode()).hexdigest()
        manager_hash = hashlib.sha256("123".encode()).hexdigest()
        customer_hash = hashlib.sha256("123".encode()).hexdigest()
        
        cursor.execute("INSERT INTO users (login, password_hash, role, full_name, email, phone, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       ("admin", admin_hash, "admin", "Администратор", "admin@obuv.ru", "+7-999-123-4567", "👑"))
        cursor.execute("INSERT INTO users (login, password_hash, role, full_name, email, phone, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       ("manager", manager_hash, "manager", "Анна Менеджер", "manager@obuv.ru", "+7-999-234-5678", "💼"))
        cursor.execute("INSERT INTO users (login, password_hash, role, full_name, email, phone, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       ("customer", customer_hash, "customer", "Иван Петров", "customer@obuv.ru", "+7-999-345-6789", "👤"))
    
    cursor.execute("SELECT COUNT(*) FROM goods")
    if cursor.fetchone()[0] == 0:
        test_goods = [
            ("Кроссовки Nike Air Max", "42", 8990, 50, 10, "Мужская", "🏃", "Легендарные кроссовки с максимальной амортизацией"),
            ("Сапоги Timberland", "41", 12990, 30, 20, "Мужская", "🥾", "Водонепроницаемые, для активного отдыха"),
            ("Туфли женские", "37", 5490, 25, 5, "Женская", "👠", "Элегантные туфли на каблуке"),
            ("Ботинки зимние", "43", 15990, 15, 25, "Мужская", "❄️", "Тёплые ботинки для холодной зимы"),
            ("Кеды Converse", "40", 4990, 40, 15, "Унисекс", "👟", "Классические кеды на все времена"),
            ("Сандалии", "38", 3990, 20, 30, "Женская", "👡", "Лёгкие сандалии для лета"),
            ("Лоферы", "42", 7990, 12, 8, "Мужская", "👞", "Стильные лоферы для офиса"),
            ("Угги", "39", 10990, 8, 18, "Женская", "👢", "Тёплые угги из натуральной овчины"),
            ("Кроссовки Adidas", "43", 10990, 45, 12, "Мужская", "🏃", "Спортивные кроссовки для бега"),
            ("Балетки", "36", 3490, 18, 10, "Женская", "🩰", "Удобные балетки на каждый день"),
        ]
        for good in test_goods:
            cursor.execute('''
                INSERT INTO goods (name, size, price, stock_quantity, discount_percent, category, image_emoji, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', good)
    
    conn.commit()
    conn.close()

def get_user(login, password):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    cursor.execute("SELECT user_id, login, role, full_name, avatar FROM users WHERE login = ? AND password_hash = ?", (login, password_hash))
    user = cursor.fetchone()
    conn.close()
    return user

def get_goods(search="", category="", sort=""):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    query = "SELECT good_id, name, size, price, stock_quantity, discount_percent, category, image_emoji, description FROM goods WHERE 1=1"
    params = []
    if search:
        query += " AND (name LIKE ? OR description LIKE ?)"
        params.append(f"%{search}%")
        params.append(f"%{search}%")
    if category and category != "Все категории":
        query += " AND category = ?"
        params.append(category)
    if sort == "price_asc":
        query += " ORDER BY price ASC"
    elif sort == "price_desc":
        query += " ORDER BY price DESC"
    elif sort == "discount_desc":
        query += " ORDER BY discount_percent DESC"
    cursor.execute(query, params)
    goods = cursor.fetchall()
    conn.close()
    return goods

def get_good_by_id(good_id):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    cursor.execute("SELECT good_id, name, size, price, stock_quantity, discount_percent, category, image_emoji, description FROM goods WHERE good_id = ?", (good_id,))
    good = cursor.fetchone()
    conn.close()
    return good

def get_cart(user_id):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT g.good_id, g.name, g.size, g.price, g.discount_percent, g.image_emoji, ci.quantity,
               (g.price * (100 - g.discount_percent) / 100) * ci.quantity as total
        FROM cart_items ci
        JOIN carts c ON ci.cart_id = c.cart_id
        JOIN goods g ON ci.good_id = g.good_id
        WHERE c.user_id = ?
    ''', (user_id,))
    items = cursor.fetchall()
    conn.close()
    return items

def add_to_cart(user_id, good_id, quantity):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    cursor.execute("SELECT cart_id FROM carts WHERE user_id = ?", (user_id,))
    cart = cursor.fetchone()
    if not cart:
        cursor.execute("INSERT INTO carts (user_id) VALUES (?)", (user_id,))
        cart_id = cursor.lastrowid
    else:
        cart_id = cart[0]
    cursor.execute('''
        INSERT INTO cart_items (cart_id, good_id, quantity)
        VALUES (?, ?, ?)
        ON CONFLICT(cart_id, good_id) DO UPDATE SET quantity = quantity + ?
    ''', (cart_id, good_id, quantity, quantity))
    conn.commit()
    conn.close()

def remove_from_cart(user_id, good_id):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    cursor.execute("SELECT cart_id FROM carts WHERE user_id = ?", (user_id,))
    cart = cursor.fetchone()
    if cart:
        cursor.execute("DELETE FROM cart_items WHERE cart_id = ? AND good_id = ?", (cart[0], good_id))
        conn.commit()
    conn.close()

def update_cart_quantity(user_id, good_id, quantity):
    if quantity <= 0:
        remove_from_cart(user_id, good_id)
        return
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    cursor.execute("SELECT cart_id FROM carts WHERE user_id = ?", (user_id,))
    cart = cursor.fetchone()
    if cart:
        cursor.execute("UPDATE cart_items SET quantity = ? WHERE cart_id = ? AND good_id = ?", (quantity, cart[0], good_id))
        conn.commit()
    conn.close()

def clear_cart(user_id):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    cursor.execute("SELECT cart_id FROM carts WHERE user_id = ?", (user_id,))
    cart = cursor.fetchone()
    if cart:
        cursor.execute("DELETE FROM cart_items WHERE cart_id = ?", (cart[0],))
        conn.commit()
    conn.close()

def create_order(user_id, delivery_address, payment_method="cash"):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    try:
        cursor.execute("BEGIN TRANSACTION")
        
        cart_items = get_cart(user_id)
        if not cart_items:
            return False, "Корзина пуста"
        
        total_amount = 0
        for item in cart_items:
            good_id = item[0]
            quantity = item[6]
            price = item[3]
            discount = item[4]
            final_price = price * (100 - discount) / 100
            total_amount += final_price * quantity
            
            cursor.execute("SELECT stock_quantity FROM goods WHERE good_id = ?", (good_id,))
            stock = cursor.fetchone()[0]
            if stock < quantity:
                return False, f"Недостаточно товара: {item[1]} (остаток {stock})"
        
        cursor.execute('''
            INSERT INTO orders (user_id, total_amount, status, delivery_address, payment_method)
            VALUES (?, ?, 'new', ?, ?)
        ''', (user_id, total_amount, delivery_address, payment_method))
        order_id = cursor.lastrowid
        
        for item in cart_items:
            good_id = item[0]
            quantity = item[6]
            price = item[3]
            discount = item[4]
            final_price = price * (100 - discount) / 100
            
            cursor.execute('''
                INSERT INTO order_details (order_id, good_id, quantity, price_at_moment)
                VALUES (?, ?, ?, ?)
            ''', (order_id, good_id, quantity, final_price))
            
            cursor.execute("UPDATE goods SET stock_quantity = stock_quantity - ? WHERE good_id = ?", (quantity, good_id))
        
        clear_cart(user_id)
        conn.commit()
        return True, order_id
    except Exception as e:
        conn.rollback()
        return False, str(e)
    finally:
        conn.close()

def get_orders(user_id=None, role="customer"):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    status_ru = {
        'new': '🟡 Новый', 'paid': '🟢 Оплачен', 'processing': '🟠 В обработке',
        'shipped': '📦 Отправлен', 'delivered': '✅ Доставлен', 'cancelled': '❌ Отменён'
    }
    if role in ("admin", "manager"):
        cursor.execute('''
            SELECT o.order_id, u.login, o.order_date, o.total_amount, o.status, o.delivery_address, o.payment_method
            FROM orders o
            JOIN users u ON o.user_id = u.user_id
            ORDER BY o.order_date DESC
        ''')
        orders = cursor.fetchall()
        orders = [(o[0], o[1], o[2], f"{o[3]:.0f} ₽", status_ru.get(o[4], o[4]), o[5], o[6]) for o in orders]
    else:
        cursor.execute('''
            SELECT order_id, order_date, total_amount, status, delivery_address, payment_method
            FROM orders
            WHERE user_id = ?
            ORDER BY order_date DESC
        ''', (user_id,))
        orders = cursor.fetchall()
        orders = [(o[0], o[1], f"{o[2]:.0f} ₽", status_ru.get(o[3], o[3]), o[4], o[5]) for o in orders]
    conn.close()
    return orders

def update_order_status(order_id, new_status):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE orders SET status = ? WHERE order_id = ?", (new_status, order_id))
    conn.commit()
    conn.close()

def add_good(name, size, price, stock, discount, category, image_emoji="👟", description=""):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO goods (name, size, price, stock_quantity, discount_percent, category, image_emoji, description)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (name, size, price, stock, discount, category, image_emoji, description))
    conn.commit()
    conn.close()

def update_good(good_id, name, size, price, stock, discount, category, image_emoji=None, description=None):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    if image_emoji is None:
        good = get_good_by_id(good_id)
        image_emoji = good[7] if good else "👟"
    if description is None:
        good = get_good_by_id(good_id)
        description = good[8] if good else ""
    cursor.execute('''
        UPDATE goods
        SET name=?, size=?, price=?, stock_quantity=?, discount_percent=?, category=?, image_emoji=?, description=?
        WHERE good_id=?
    ''', (name, size, price, stock, discount, category, image_emoji, description, good_id))
    conn.commit()
    conn.close()

def delete_good(good_id):
    conn = sqlite3.connect('shoe_store.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM goods WHERE good_id = ?", (good_id,))
    conn.commit()
    conn.close()

# ==================== КЛАССЫ ОКОН ====================

class LoginWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("👟 ООО Обувь - Вход в систему")
        self.root.geometry("500x400")
        self.root.configure(bg=BG_HEADER)
        self.root.resizable(False, False)
        
        setup_styles()
        self.center_window()
        
        # Основная карточка
        card = tk.Frame(root, bg=BG_PRIMARY, relief=tk.RAISED, bd=1)
        card.place(relx=0.5, rely=0.5, anchor="center", width=380, height=340)
        
        # Логотип
        logo_frame = tk.Frame(card, bg=BG_PRIMARY)
        logo_frame.pack(pady=25)
        logo_label = tk.Label(logo_frame, text="👟", font=("Segoe UI", 48), bg=BG_PRIMARY)
        logo_label.pack()
        title_label = tk.Label(logo_frame, text="ООО ОБУВЬ", font=(FONT_FAMILY, 20, "bold"), bg=BG_PRIMARY, fg=BG_HIGH_DISCOUNT)
        title_label.pack()
        
        # Поля ввода
        input_frame = tk.Frame(card, bg=BG_PRIMARY)
        input_frame.pack(pady=20, padx=30, fill=tk.X)
        
        self.entry_login = tk.Entry(input_frame, font=(FONT_FAMILY, 12), relief=tk.GROOVE, bd=1)
        self.entry_login.pack(fill=tk.X, pady=(0, 15))
        self.entry_login.insert(0, "Логин")
        self.entry_login.bind('<FocusIn>', lambda e: self.entry_login.delete(0, tk.END) if self.entry_login.get() == "Логин" else None)
        
        self.entry_password = tk.Entry(input_frame, show="•", font=(FONT_FAMILY, 12), relief=tk.GROOVE, bd=1)
        self.entry_password.pack(fill=tk.X, pady=(0, 20))
        self.entry_password.insert(0, "Пароль")
        self.entry_password.bind('<FocusIn>', lambda e: self.entry_password.delete(0, tk.END) if self.entry_password.get() == "Пароль" else None)
        
        # Кнопки
        btn_frame = tk.Frame(card, bg=BG_PRIMARY)
        btn_frame.pack(fill=tk.X, padx=30)
        
        btn_login = tk.Button(btn_frame, text="🔑 Войти", font=(FONT_FAMILY, 11, "bold"),
                              bg=BG_ACCENT, fg="black", relief=tk.FLAT, bd=0,
                              command=self.login, cursor="hand2")
        btn_login.pack(side=tk.LEFT, padx=(0, 10), fill=tk.X, expand=True, ipady=6)
        
        btn_guest = tk.Button(btn_frame, text="👤 Гость", font=(FONT_FAMILY, 11),
                              bg=BG_SECONDARY, fg="black", relief=tk.FLAT, bd=0,
                              command=self.guest_login, cursor="hand2")
        btn_guest.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=6)
        
        # Инфо
        info_label = tk.Label(card, text="Тестовые данные: admin/123, manager/123, customer/123",
                              font=(FONT_FAMILY, 8), bg=BG_PRIMARY, fg="#999")
        info_label.pack(pady=15)
    
    def center_window(self):
        self.root.update_idletasks()
        w = 500
        h = 400
        x = (self.root.winfo_screenwidth() // 2) - (w // 2)
        y = (self.root.winfo_screenheight() // 2) - (h // 2)
        self.root.geometry(f'{w}x{h}+{x}+{y}')
    
    def login(self):
        login = self.entry_login.get()
        password = self.entry_password.get()
        if login in ("Логин", "") or password in ("Пароль", ""):
            messagebox.showwarning("Внимание", "Введите логин и пароль")
            return
        user = get_user(login, password)
        if user:
            self.root.destroy()
            main_window = tk.Tk()
            if user[2] == "admin":
                AdminWindow(main_window, user)
            elif user[2] == "manager":
                ManagerWindow(main_window, user)
            else:
                CustomerWindow(main_window, user)
            main_window.mainloop()
        else:
            messagebox.showerror("Ошибка", "Неверный логин или пароль")
    
    def guest_login(self):
        self.root.destroy()
        guest_window = tk.Tk()
        GuestWindow(guest_window)
        guest_window.mainloop()

class GuestWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("👟 ООО Обувь - Режим гостя")
        self.root.geometry("1200x700")
        self.root.configure(bg=BG_SECONDARY)
        
        setup_styles()
        
        # Верхняя панель
        header = tk.Frame(root, bg=BG_HEADER, height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        tk.Label(header, text="👟 ООО ОБУВЬ", font=(FONT_FAMILY, 18, "bold"),
                 bg=BG_HEADER, fg=FG_WHITE).pack(side=tk.LEFT, padx=25, pady=15)
        tk.Label(header, text="Добро пожаловать! Для покупок войдите в систему",
                 font=(FONT_FAMILY, 11), bg=BG_HEADER, fg=FG_WHITE).pack(side=tk.LEFT, padx=20)
        
        btn_exit = tk.Button(header, text="🚪 Выйти", font=(FONT_FAMILY, 10),
                             bg=BG_ACCENT, relief=tk.FLAT, command=self.logout, cursor="hand2")
        btn_exit.pack(side=tk.RIGHT, padx=25)
        
        # Контейнер для карточек с прокруткой
        canvas_frame = tk.Frame(root, bg=BG_SECONDARY)
        canvas_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        self.canvas = tk.Canvas(canvas_frame, bg=BG_SECONDARY, highlightthickness=0)
        scrollbar = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg=BG_SECONDARY)
        
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.load_goods()
    
    def load_goods(self):
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()
        
        goods = get_goods()
        row = 0
        col = 0
        for good in goods:
            self.create_product_card(good, row, col)
            col += 1
            if col >= 4:
                col = 0
                row += 1
    
    def create_product_card(self, good, row, col):
        good_id, name, size, price, stock, discount, category, emoji, desc = good
        discounted_price = price * (100 - discount) / 100
        
        card = tk.Frame(self.scrollable_frame, bg=CARD_BG, relief=tk.RAISED, bd=1)
        card.grid(row=row, column=col, padx=15, pady=15, sticky="nsew")
        
        # Картинка
        img_label = tk.Label(card, text=emoji, font=("Segoe UI", 48), bg=CARD_BG)
        img_label.pack(pady=15)
        
        # Название
        name_label = tk.Label(card, text=name, font=(FONT_FAMILY, 12, "bold"), bg=CARD_BG, wraplength=200)
        name_label.pack(pady=(0, 5))
        
        # Размер
        size_label = tk.Label(card, text=f"Размер: {size}", font=(FONT_FAMILY, 10), bg=CARD_BG, fg="#666")
        size_label.pack()
        
        # Цена
        if discount > 0:
            old_price_label = tk.Label(card, text=f"{price:.0f} ₽", font=("Times New Roman", 9, "overstrike"), bg=CARD_BG, fg="#999")
            old_price_label.pack()
            price_label = tk.Label(card, text=f"{discounted_price:.0f} ₽", font=(FONT_FAMILY, 16, "bold"), 
                                   bg=CARD_BG, fg=BG_HIGH_DISCOUNT if discount > 15 else "#333")
            price_label.pack()
            discount_label = tk.Label(card, text=f"-{discount}%", font=(FONT_FAMILY, 9), bg=BG_ACCENT, fg="black", padx=5, pady=2)
            discount_label.pack(pady=(5, 0))
        else:
            price_label = tk.Label(card, text=f"{price:.0f} ₽", font=(FONT_FAMILY, 16, "bold"), bg=CARD_BG, fg="#333")
            price_label.pack()
        
        # Остаток
        stock_color = "#4CAF50" if stock > 0 else "#f44336"
        stock_label = tk.Label(card, text=f"В наличии: {stock} шт", font=(FONT_FAMILY, 9), bg=CARD_BG, fg=stock_color)
        stock_label.pack(pady=(5, 10))
        
        if discount > 15:
            card.configure(bg=BG_HIGH_DISCOUNT)
            for w in card.winfo_children():
                w.configure(bg=BG_HIGH_DISCOUNT)
                if isinstance(w, tk.Label) and w.cget("fg") not in ("#333", "#666"):
                    w.configure(fg=FG_WHITE)
    
    def logout(self):
        self.root.destroy()
        root = tk.Tk()
        LoginWindow(root)
        root.mainloop()

class CustomerWindow:
    def __init__(self, root, user):
        self.root = root
        self.user = user
        self.root.title(f"👟 ООО Обувь - {user[3]}")
        self.root.geometry("1300x750")
        self.root.configure(bg=BG_SECONDARY)
        
        setup_styles()
        
        # Боковая панель
        self.sidebar = tk.Frame(root, bg=BG_HIGH_DISCOUNT, width=200)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.pack_propagate(False)
        
        # Аватар
        avatar_frame = tk.Frame(self.sidebar, bg=BG_HIGH_DISCOUNT)
        avatar_frame.pack(pady=30)
        avatar_label = tk.Label(avatar_frame, text=user[4], font=("Segoe UI", 48), bg=BG_HIGH_DISCOUNT)
        avatar_label.pack()
        name_label = tk.Label(avatar_frame, text=user[3], font=(FONT_FAMILY, 14, "bold"), bg=BG_HIGH_DISCOUNT, fg=FG_WHITE)
        name_label.pack()
        
        # Навигация
        nav_frame = tk.Frame(self.sidebar, bg=BG_HIGH_DISCOUNT)
        nav_frame.pack(fill=tk.X, pady=20)
        
        self.nav_btn_catalog = self.create_nav_button(nav_frame, "📦 Каталог", self.show_catalog)
        self.nav_btn_catalog.pack(fill=tk.X, padx=15, pady=5)
        
        self.nav_btn_cart = self.create_nav_button(nav_frame, "🛍 Корзина", self.show_cart)
        self.nav_btn_cart.pack(fill=tk.X, padx=15, pady=5)
        
        self.nav_btn_orders = self.create_nav_button(nav_frame, "📋 Заказы", self.show_orders)
        self.nav_btn_orders.pack(fill=tk.X, padx=15, pady=5)
        
        # Выход
        logout_btn = self.create_nav_button(nav_frame, "🚪 Выход", self.logout, "#555")
        logout_btn.pack(fill=tk.X, padx=15, pady=5, side=tk.BOTTOM)
        
        # Основной контент
        self.content_frame = tk.Frame(root, bg=BG_SECONDARY)
        self.content_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.show_catalog()
    
    def create_nav_button(self, parent, text, command, color=None):
        btn = tk.Button(parent, text=text, font=(FONT_FAMILY, 11), 
                        bg=color if color else BG_HIGH_DISCOUNT, fg=FG_WHITE,
                        relief=tk.FLAT, anchor="w", padx=15, pady=12,
                        command=command, cursor="hand2")
        return btn
    
    def highlight_nav(self, active_btn):
        for btn in [self.nav_btn_catalog, self.nav_btn_cart, self.nav_btn_orders]:
            btn.configure(bg=BG_HIGH_DISCOUNT, fg=FG_WHITE)
        active_btn.configure(bg=BG_ACCENT, fg="black")
    
    def show_catalog(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        self.highlight_nav(self.nav_btn_catalog)
        
        # Верхняя панель фильтров
        filter_frame = tk.Frame(self.content_frame, bg=BG_PRIMARY, relief=tk.RAISED)
        filter_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(filter_frame, text="🔍 Поиск:", font=(FONT_FAMILY, 11), bg=BG_PRIMARY).pack(side=tk.LEFT, padx=(15, 5), pady=12)
        self.search_entry = tk.Entry(filter_frame, font=(FONT_FAMILY, 11), width=20, relief=tk.GROOVE)
        self.search_entry.pack(side=tk.LEFT, padx=5, pady=12)
        
        tk.Label(filter_frame, text="📂 Категория:", font=(FONT_FAMILY, 11), bg=BG_PRIMARY).pack(side=tk.LEFT, padx=(15, 5), pady=12)
        self.category_var = tk.StringVar(value="Все категории")
        categories = ["Все категории", "Мужская", "Женская", "Унисекс"]
        self.category_combo = ttk.Combobox(filter_frame, textvariable=self.category_var, values=categories, width=14)
        self.category_combo.pack(side=tk.LEFT, padx=5, pady=12)
        
        tk.Label(filter_frame, text="📊 Сортировка:", font=(FONT_FAMILY, 11), bg=BG_PRIMARY).pack(side=tk.LEFT, padx=(15, 5), pady=12)
        self.sort_var = tk.StringVar(value="Без сортировки")
        sort_options = ["Без сортировки", "💰 Цена ↑", "💰 Цена ↓", "🎁 Скидка ↓"]
        self.sort_combo = ttk.Combobox(filter_frame, textvariable=self.sort_var, values=sort_options, width=14)
        self.sort_combo.pack(side=tk.LEFT, padx=5, pady=12)
        
        btn_search = tk.Button(filter_frame, text="🔍 Найти", command=self.load_catalog,
                               bg=BG_ACCENT, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_search.pack(side=tk.LEFT, padx=20, pady=12)
        
        btn_reset = tk.Button(filter_frame, text="🔄 Сбросить", command=self.reset_filters,
                              bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_reset.pack(side=tk.LEFT, pady=12)
        
        # Контейнер для карточек
        canvas_frame = tk.Frame(self.content_frame, bg=BG_SECONDARY)
        canvas_frame.pack(fill=tk.BOTH, expand=True)
        
        self.canvas = tk.Canvas(canvas_frame, bg=BG_SECONDARY, highlightthickness=0)
        scrollbar = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg=BG_SECONDARY)
        
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Корзина внизу
        cart_panel = tk.Frame(self.content_frame, bg=BG_ACCENT, height=50)
        cart_panel.pack(fill=tk.X, side=tk.BOTTOM)
        cart_panel.pack_propagate(False)
        
        tk.Label(cart_panel, text="🛒", font=("Segoe UI", 20), bg=BG_ACCENT).pack(side=tk.LEFT, padx=15)
        tk.Label(cart_panel, text="Корзина", font=(FONT_FAMILY, 12, "bold"), bg=BG_ACCENT).pack(side=tk.LEFT)
        
        self.qty_spinbox = tk.Spinbox(cart_panel, from_=1, to=99, width=5, font=(FONT_FAMILY, 11), relief=tk.GROOVE)
        self.qty_spinbox.pack(side=tk.RIGHT, padx=10)
        
        btn_add = tk.Button(cart_panel, text="➕ Добавить в корзину", command=self.add_to_cart,
                            bg=BG_ACCENT, fg="black", font=(FONT_FAMILY, 11, "bold"), relief=tk.FLAT, cursor="hand2")
        btn_add.pack(side=tk.RIGHT, padx=10)
        
        self.load_catalog()
    
    def load_catalog(self):
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()
        
        search = self.search_entry.get()
        category = self.category_var.get()
        sort_map = {"💰 Цена ↑": "price_asc", "💰 Цена ↓": "price_desc", "🎁 Скидка ↓": "discount_desc"}
        sort = sort_map.get(self.sort_var.get(), "")
        
        goods = get_goods(search, category, sort)
        row = 0
        col = 0
        for good in goods:
            self.create_product_card(good, row, col)
            col += 1
            if col >= 4:
                col = 0
                row += 1
    
    def create_product_card(self, good, row, col):
        good_id, name, size, price, stock, discount, category, emoji, desc = good
        discounted_price = price * (100 - discount) / 100
        
        card = tk.Frame(self.scrollable_frame, bg=CARD_BG, relief=tk.RAISED, bd=1)
        card.grid(row=row, column=col, padx=15, pady=15, sticky="nsew")
        card.good_id = good_id
        
        # Картинка
        img_label = tk.Label(card, text=emoji, font=("Segoe UI", 48), bg=CARD_BG)
        img_label.pack(pady=15)
        
        # Название
        name_label = tk.Label(card, text=name, font=(FONT_FAMILY, 12, "bold"), bg=CARD_BG, wraplength=200)
        name_label.pack(pady=(0, 5))
        
        # Размер
        size_label = tk.Label(card, text=f"Размер: {size}", font=(FONT_FAMILY, 10), bg=CARD_BG, fg="#666")
        size_label.pack()
        
        # Цена
        if discount > 0:
            old_price_label = tk.Label(card, text=f"{price:.0f} ₽", font=("Times New Roman", 9, "overstrike"), bg=CARD_BG, fg="#999")
            old_price_label.pack()
            price_label = tk.Label(card, text=f"{discounted_price:.0f} ₽", font=(FONT_FAMILY, 16, "bold"), 
                                   bg=CARD_BG, fg=BG_HIGH_DISCOUNT if discount > 15 else "#333")
            price_label.pack()
            discount_label = tk.Label(card, text=f"-{discount}%", font=(FONT_FAMILY, 9), bg=BG_ACCENT, fg="black", padx=5, pady=2)
            discount_label.pack(pady=(5, 0))
        else:
            price_label = tk.Label(card, text=f"{price:.0f} ₽", font=(FONT_FAMILY, 16, "bold"), bg=CARD_BG, fg="#333")
            price_label.pack()
        
        # Остаток
        stock_color = "#4CAF50" if stock > 0 else "#f44336"
        stock_label = tk.Label(card, text=f"В наличии: {stock} шт", font=(FONT_FAMILY, 9), bg=CARD_BG, fg=stock_color)
        stock_label.pack(pady=(5, 10))
        
        # Кнопка добавления
        add_btn = tk.Button(card, text="➕ В корзину", command=lambda: self.add_single_to_cart(good_id, name),
                            bg=BG_ACCENT, relief=tk.FLAT, cursor="hand2", padx=10)
        add_btn.pack(pady=(0, 10))
        
        if discount > 15:
            card.configure(bg=BG_HIGH_DISCOUNT)
            for w in card.winfo_children():
                w.configure(bg=BG_HIGH_DISCOUNT)
                if isinstance(w, tk.Label) and w.cget("fg") not in ("#333", "#666"):
                    w.configure(fg=FG_WHITE)
    
    def add_single_to_cart(self, good_id, name):
        add_to_cart(self.user[0], good_id, 1)
        messagebox.showinfo("Успех", f"✅ {name} добавлен в корзину")
    
    def add_to_cart(self):
        messagebox.showinfo("Выбор товара", "Нажмите кнопку 'В корзину' на карточке товара")
    
    def reset_filters(self):
        self.search_entry.delete(0, tk.END)
        self.category_var.set("Все категории")
        self.sort_var.set("Без сортировки")
        self.load_catalog()
    
    def show_cart(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        self.highlight_nav(self.nav_btn_cart)
        CartWindowContent(self.content_frame, self.user, self)
    
    def show_orders(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        self.highlight_nav(self.nav_btn_orders)
        OrdersWindowContent(self.content_frame, self.user, "customer", self)
    
    def logout(self):
        if messagebox.askyesno("Выход", "Вы уверены, что хотите выйти?"):
            self.root.destroy()
            root = tk.Tk()
            LoginWindow(root)
            root.mainloop()

class CartWindowContent:
    def __init__(self, parent, user, main_window):
        self.parent = parent
        self.user = user
        self.main_window = main_window
        self.create_widgets()
        self.load_cart()
    
    def create_widgets(self):
        header = tk.Frame(self.parent, bg=BG_PRIMARY, relief=tk.RAISED)
        header.pack(fill=tk.X, pady=(0, 15))
        tk.Label(header, text="🛍 Корзина покупок", font=(FONT_FAMILY, 18, "bold"), bg=BG_PRIMARY, fg=BG_HIGH_DISCOUNT).pack(pady=15)
        
        columns = ("ID", "Товар", "Размер", "Цена", "Скидка", "Кол-во", "Итого")
        self.tree = ttk.Treeview(self.parent, columns=columns, show="headings", height=18)
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=110)
        self.tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        btn_frame = tk.Frame(self.parent, bg=BG_SECONDARY)
        btn_frame.pack(pady=10)
        
        btn_remove = tk.Button(btn_frame, text="🗑 Удалить", command=self.remove_item,
                               bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_remove.pack(side=tk.LEFT, padx=5)
        
        btn_update = tk.Button(btn_frame, text="✏️ Изменить кол-во", command=self.update_quantity,
                               bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_update.pack(side=tk.LEFT, padx=5)
        
        btn_clear = tk.Button(btn_frame, text="🗑 Очистить", command=self.clear_cart,
                              bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_clear.pack(side=tk.LEFT, padx=5)
        
        btn_order = tk.Button(btn_frame, text="✅ Оформить заказ", command=self.checkout,
                              bg=BG_ACCENT, font=(FONT_FAMILY, 11, "bold"), relief=tk.FLAT, cursor="hand2", padx=20)
        btn_order.pack(side=tk.LEFT, padx=20)
        
        btn_back = tk.Button(btn_frame, text="← Назад", command=self.go_back,
                             bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_back.pack(side=tk.LEFT, padx=5)
    
    def load_cart(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        items = get_cart(self.user[0])
        total_all = 0
        for item in items:
            good_id, name, size, price, discount, emoji, qty, total = item
            self.tree.insert("", tk.END, values=(good_id, f"{emoji} {name}", size, f"{price:.0f} ₽", f"{discount}%", qty, f"{total:.0f} ₽"))
            total_all += total
        if items:
            self.tree.insert("", tk.END, values=("", "", "", "", "", "ИТОГО:", f"{total_all:.0f} ₽"))
    
    def remove_item(self):
        selected = self.tree.selection()
        if selected:
            values = self.tree.item(selected[0])['values']
            if values[0] and values[0] != "":
                remove_from_cart(self.user[0], values[0])
                self.load_cart()
                messagebox.showinfo("Успех", "Товар удалён из корзины")
    
    def update_quantity(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Внимание", "Выберите товар")
            return
        values = self.tree.item(selected[0])['values']
        if not values[0] or values[0] == "":
            return
        new_qty = simpledialog.askinteger("Изменить количество", "Введите новое количество:", initialvalue=values[5])
        if new_qty and new_qty > 0:
            update_cart_quantity(self.user[0], values[0], new_qty)
            self.load_cart()
    
    def clear_cart(self):
        if messagebox.askyesno("Очистка", "Очистить всю корзину?"):
            clear_cart(self.user[0])
            self.load_cart()
    
    def checkout(self):
        address = simpledialog.askstring("Доставка", "Введите адрес доставки:")
        if address:
            payment = simpledialog.askstring("Оплата", "Способ оплаты (cash/card):", initialvalue="cash")
            if payment:
                success, result = create_order(self.user[0], address, payment)
                if success:
                    messagebox.showinfo("Успех", f"✅ Заказ №{result} успешно оформлен!\nДоставка по адресу: {address}")
                    self.go_back()
                else:
                    messagebox.showerror("Ошибка", f"❌ Не удалось оформить заказ:\n{result}")
    
    def go_back(self):
        self.main_window.show_catalog()

class OrdersWindowContent:
    def __init__(self, parent, user, role, main_window):
        self.parent = parent
        self.user = user
        self.role = role
        self.main_window = main_window
        self.create_widgets()
        self.load_orders()
    
    def create_widgets(self):
        header = tk.Frame(self.parent, bg=BG_PRIMARY, relief=tk.RAISED)
        header.pack(fill=tk.X, pady=(0, 15))
        tk.Label(header, text="📋 История заказов", font=(FONT_FAMILY, 18, "bold"), bg=BG_PRIMARY, fg=BG_HIGH_DISCOUNT).pack(pady=15)
        
        if self.role in ("manager", "admin"):
            columns = ("№", "Покупатель", "Дата", "Сумма", "Статус", "Адрес", "Оплата")
        else:
            columns = ("№", "Дата", "Сумма", "Статус", "Адрес", "Оплата")
        
        self.tree = ttk.Treeview(self.parent, columns=columns, show="headings", height=18)
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120)
        self.tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        btn_frame = tk.Frame(self.parent, bg=BG_SECONDARY)
        btn_frame.pack(pady=10)
        
        if self.role in ("manager", "admin"):
            tk.Label(btn_frame, text="Новый статус:", bg=BG_SECONDARY, font=(FONT_FAMILY, 10)).pack(side=tk.LEFT, padx=5)
            self.status_var = tk.StringVar(value="new")
            status_combo = ttk.Combobox(btn_frame, textvariable=self.status_var,
                                        values=["new", "paid", "processing", "shipped", "delivered", "cancelled"],
                                        width=14)
            status_combo.pack(side=tk.LEFT, padx=5)
            btn_update = tk.Button(btn_frame, text="🔄 Обновить статус", command=self.update_status,
                                   bg=BG_ACCENT, relief=tk.FLAT, cursor="hand2", padx=15)
            btn_update.pack(side=tk.LEFT, padx=10)
        
        btn_back = tk.Button(btn_frame, text="← Назад", command=self.go_back,
                             bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_back.pack(side=tk.LEFT, padx=5)
    
    def load_orders(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        orders = get_orders(self.user[0], self.role)
        for order in orders:
            self.tree.insert("", tk.END, values=order)
    
    def update_status(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Внимание", "Выберите заказ")
            return
        order_id = self.tree.item(selected[0])['values'][0]
        new_status = self.status_var.get()
        update_order_status(order_id, new_status)
        self.load_orders()
        messagebox.showinfo("Успех", f"Статус заказа №{order_id} изменён")
    
    def go_back(self):
        self.main_window.show_catalog()

class ManagerWindow:
    def __init__(self, root, user):
        self.root = root
        self.user = user
        self.root.title(f"👔 ООО Обувь - Панель менеджера: {user[3]}")
        self.root.geometry("1300x750")
        self.root.configure(bg=BG_SECONDARY)
        
        setup_styles()
        
        # Боковая панель
        self.sidebar = tk.Frame(root, bg=BG_HIGH_DISCOUNT, width=200)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.pack_propagate(False)
        
        avatar_frame = tk.Frame(self.sidebar, bg=BG_HIGH_DISCOUNT)
        avatar_frame.pack(pady=30)
        avatar_label = tk.Label(avatar_frame, text=user[4], font=("Segoe UI", 48), bg=BG_HIGH_DISCOUNT)
        avatar_label.pack()
        name_label = tk.Label(avatar_frame, text=user[3], font=(FONT_FAMILY, 14, "bold"), bg=BG_HIGH_DISCOUNT, fg=FG_WHITE)
        name_label.pack()
        
        nav_frame = tk.Frame(self.sidebar, bg=BG_HIGH_DISCOUNT)
        nav_frame.pack(fill=tk.X, pady=20)
        
        self.nav_btn_orders = self.create_nav_button(nav_frame, "📋 Заказы", self.show_orders)
        self.nav_btn_orders.pack(fill=tk.X, padx=15, pady=5)
        
        self.nav_btn_catalog = self.create_nav_button(nav_frame, "📦 Каталог", self.show_catalog)
        self.nav_btn_catalog.pack(fill=tk.X, padx=15, pady=5)
        
        logout_btn = self.create_nav_button(nav_frame, "🚪 Выход", self.logout, "#555")
        logout_btn.pack(fill=tk.X, padx=15, pady=5, side=tk.BOTTOM)
        
        self.content_frame = tk.Frame(root, bg=BG_SECONDARY)
        self.content_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.show_orders()
    
    def create_nav_button(self, parent, text, command, color=None):
        btn = tk.Button(parent, text=text, font=(FONT_FAMILY, 11), 
                        bg=color if color else BG_HIGH_DISCOUNT, fg=FG_WHITE,
                        relief=tk.FLAT, anchor="w", padx=15, pady=12,
                        command=command, cursor="hand2")
        return btn
    
    def highlight_nav(self, active_btn):
        for btn in [self.nav_btn_orders, self.nav_btn_catalog]:
            btn.configure(bg=BG_HIGH_DISCOUNT, fg=FG_WHITE)
        active_btn.configure(bg=BG_ACCENT, fg="black")
    
    def show_orders(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        self.highlight_nav(self.nav_btn_orders)
        self.create_orders_content()
    
    def create_orders_content(self):
        header = tk.Frame(self.content_frame, bg=BG_PRIMARY, relief=tk.RAISED)
        header.pack(fill=tk.X, pady=(0, 15))
        tk.Label(header, text="📋 Управление заказами", font=(FONT_FAMILY, 18, "bold"), bg=BG_PRIMARY, fg=BG_HIGH_DISCOUNT).pack(pady=15)
        
        columns = ("№", "Покупатель", "Дата", "Сумма", "Статус", "Адрес", "Оплата")
        self.orders_tree = ttk.Treeview(self.content_frame, columns=columns, show="headings", height=20)
        for col in columns:
            self.orders_tree.heading(col, text=col)
            self.orders_tree.column(col, width=120)
        self.orders_tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        btn_frame = tk.Frame(self.content_frame, bg=BG_SECONDARY)
        btn_frame.pack(pady=10)
        
        tk.Label(btn_frame, text="Новый статус:", bg=BG_SECONDARY, font=(FONT_FAMILY, 10)).pack(side=tk.LEFT, padx=5)
        self.status_var = tk.StringVar(value="new")
        status_combo = ttk.Combobox(btn_frame, textvariable=self.status_var,
                                    values=["new", "paid", "processing", "shipped", "delivered", "cancelled"],
                                    width=14)
        status_combo.pack(side=tk.LEFT, padx=5)
        btn_update = tk.Button(btn_frame, text="🔄 Обновить статус", command=self.update_order_status,
                               bg=BG_ACCENT, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_update.pack(side=tk.LEFT, padx=10)
        
        self.load_orders()
    
    def load_orders(self):
        for row in self.orders_tree.get_children():
            self.orders_tree.delete(row)
        orders = get_orders(role="manager")
        for order in orders:
            self.orders_tree.insert("", tk.END, values=order)
    
    def update_order_status(self):
        selected = self.orders_tree.selection()
        if not selected:
            messagebox.showwarning("Внимание", "Выберите заказ")
            return
        order_id = self.orders_tree.item(selected[0])['values'][0]
        new_status = self.status_var.get()
        update_order_status(order_id, new_status)
        self.load_orders()
        messagebox.showinfo("Успех", f"Статус заказа №{order_id} обновлён")
    
    def show_catalog(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        self.highlight_nav(self.nav_btn_catalog)
        self.create_catalog_content()
    
    def create_catalog_content(self):
        filter_frame = tk.Frame(self.content_frame, bg=BG_PRIMARY, relief=tk.RAISED)
        filter_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(filter_frame, text="🔍 Поиск:", bg=BG_PRIMARY).pack(side=tk.LEFT, padx=(15, 5), pady=12)
        self.search_entry = tk.Entry(filter_frame, width=20, relief=tk.GROOVE)
        self.search_entry.pack(side=tk.LEFT, padx=5, pady=12)
        
        tk.Label(filter_frame, text="📂 Категория:", bg=BG_PRIMARY).pack(side=tk.LEFT, padx=(15, 5), pady=12)
        self.category_var = tk.StringVar(value="Все категории")
        categories = ["Все категории", "Мужская", "Женская", "Унисекс"]
        self.category_combo = ttk.Combobox(filter_frame, textvariable=self.category_var, values=categories, width=14)
        self.category_combo.pack(side=tk.LEFT, padx=5, pady=12)
        
        btn_search = tk.Button(filter_frame, text="🔍 Найти", command=self.load_catalog_goods,
                               bg=BG_ACCENT, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_search.pack(side=tk.LEFT, padx=20, pady=12)
        
        columns = ("ID", "Товар", "Размер", "Цена", "Остаток", "Скидка", "Категория")
        self.tree = ttk.Treeview(self.content_frame, columns=columns, show="headings", height=20)
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120)
        self.tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.load_catalog_goods()
    
    def load_catalog_goods(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        search = self.search_entry.get()
        category = self.category_var.get()
        goods = get_goods(search, category)
        for good in goods:
            good_id, name, size, price, stock, discount, cat, emoji, desc = good
            discounted_price = price * (100 - discount) / 100
            tags = ('high_discount',) if discount > 15 else ()
            self.tree.insert("", tk.END, values=(good_id, f"{emoji} {name}", size, f"{discounted_price:.0f} ₽", stock, f"{discount}%", cat), tags=tags)
        self.tree.tag_configure('high_discount', background=BG_HIGH_DISCOUNT, foreground=FG_WHITE)
    
    def logout(self):
        if messagebox.askyesno("Выход", "Вы уверены?"):
            self.root.destroy()
            root = tk.Tk()
            LoginWindow(root)
            root.mainloop()

class AdminWindow:
    def __init__(self, root, user):
        self.root = root
        self.user = user
        self.root.title(f"⚙️ ООО Обувь - Администратор: {user[3]}")
        self.root.geometry("1400x800")
        self.root.configure(bg=BG_SECONDARY)
        
        setup_styles()
        
        # Боковая панель
        self.sidebar = tk.Frame(root, bg=BG_HIGH_DISCOUNT, width=220)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.pack_propagate(False)
        
        avatar_frame = tk.Frame(self.sidebar, bg=BG_HIGH_DISCOUNT)
        avatar_frame.pack(pady=30)
        avatar_label = tk.Label(avatar_frame, text=user[4], font=("Segoe UI", 48), bg=BG_HIGH_DISCOUNT)
        avatar_label.pack()
        name_label = tk.Label(avatar_frame, text=user[3], font=(FONT_FAMILY, 14, "bold"), bg=BG_HIGH_DISCOUNT, fg=FG_WHITE)
        name_label.pack()
        role_label = tk.Label(avatar_frame, text="Администратор", font=(FONT_FAMILY, 10), bg=BG_HIGH_DISCOUNT, fg="#CCC")
        role_label.pack()
        
        nav_frame = tk.Frame(self.sidebar, bg=BG_HIGH_DISCOUNT)
        nav_frame.pack(fill=tk.X, pady=20)
        
        self.nav_btn_goods = self.create_nav_button(nav_frame, "📦 Товары", self.show_goods)
        self.nav_btn_goods.pack(fill=tk.X, padx=15, pady=5)
        
        self.nav_btn_orders = self.create_nav_button(nav_frame, "📋 Заказы", self.show_orders)
        self.nav_btn_orders.pack(fill=tk.X, padx=15, pady=5)
        
        logout_btn = self.create_nav_button(nav_frame, "🚪 Выход", self.logout, "#555")
        logout_btn.pack(fill=tk.X, padx=15, pady=5, side=tk.BOTTOM)
        
        self.content_frame = tk.Frame(root, bg=BG_SECONDARY)
        self.content_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.show_goods()
    
    def create_nav_button(self, parent, text, command, color=None):
        btn = tk.Button(parent, text=text, font=(FONT_FAMILY, 11), 
                        bg=color if color else BG_HIGH_DISCOUNT, fg=FG_WHITE,
                        relief=tk.FLAT, anchor="w", padx=15, pady=12,
                        command=command, cursor="hand2")
        return btn
    
    def highlight_nav(self, active_btn):
        for btn in [self.nav_btn_goods, self.nav_btn_orders]:
            btn.configure(bg=BG_HIGH_DISCOUNT, fg=FG_WHITE)
        active_btn.configure(bg=BG_ACCENT, fg="black")
    
    def show_goods(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        self.highlight_nav(self.nav_btn_goods)
        
        header = tk.Frame(self.content_frame, bg=BG_PRIMARY, relief=tk.RAISED)
        header.pack(fill=tk.X, pady=(0, 15))
        tk.Label(header, text="📦 Управление товарами", font=(FONT_FAMILY, 18, "bold"), bg=BG_PRIMARY, fg=BG_HIGH_DISCOUNT).pack(side=tk.LEFT, padx=20, pady=15)
        
        btn_add = tk.Button(header, text="➕ Добавить товар", command=self.add_good_dialog,
                            bg=BG_ACCENT, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_add.pack(side=tk.RIGHT, padx=20)
        
        filter_frame = tk.Frame(self.content_frame, bg=BG_PRIMARY, relief=tk.RAISED)
        filter_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(filter_frame, text="🔍 Поиск:", bg=BG_PRIMARY).pack(side=tk.LEFT, padx=(15, 5), pady=12)
        self.search_entry = tk.Entry(filter_frame, width=20, relief=tk.GROOVE)
        self.search_entry.pack(side=tk.LEFT, padx=5, pady=12)
        
        tk.Label(filter_frame, text="📂 Категория:", bg=BG_PRIMARY).pack(side=tk.LEFT, padx=(15, 5), pady=12)
        self.category_var = tk.StringVar(value="Все категории")
        categories = ["Все категории", "Мужская", "Женская", "Унисекс"]
        self.category_combo = ttk.Combobox(filter_frame, textvariable=self.category_var, values=categories, width=14)
        self.category_combo.pack(side=tk.LEFT, padx=5, pady=12)
        
        btn_search = tk.Button(filter_frame, text="🔍 Найти", command=self.load_goods,
                               bg=BG_ACCENT, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_search.pack(side=tk.LEFT, padx=20, pady=12)
        
        columns = ("ID", "Товар", "Размер", "Цена", "Остаток", "Скидка", "Категория")
        self.tree = ttk.Treeview(self.content_frame, columns=columns, show="headings", height=20)
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120)
        self.tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        btn_frame = tk.Frame(self.content_frame, bg=BG_SECONDARY)
        btn_frame.pack(pady=10)
        btn_edit = tk.Button(btn_frame, text="✏️ Редактировать", command=self.edit_good_dialog,
                             bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_edit.pack(side=tk.LEFT, padx=10)
        btn_delete = tk.Button(btn_frame, text="🗑 Удалить", command=self.delete_good,
                               bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_delete.pack(side=tk.LEFT, padx=10)
        
        self.load_goods()
    
    def load_goods(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        search = self.search_entry.get()
        category = self.category_var.get()
        goods = get_goods(search, category)
        for good in goods:
            good_id, name, size, price, stock, discount, cat, emoji, desc = good
            discounted_price = price * (100 - discount) / 100
            tags = ('high_discount',) if discount > 15 else ()
            self.tree.insert("", tk.END, values=(good_id, f"{emoji} {name}", size, f"{discounted_price:.0f} ₽", stock, f"{discount}%", cat), tags=tags)
        self.tree.tag_configure('high_discount', background=BG_HIGH_DISCOUNT, foreground=FG_WHITE)
    
    def add_good_dialog(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("➕ Добавление товара")
        dialog.geometry("450x500")
        dialog.configure(bg=BG_PRIMARY)
        dialog.resizable(False, False)
        
        tk.Label(dialog, text="➕ Новый товар", font=(FONT_FAMILY, 16, "bold"), bg=BG_PRIMARY, fg=BG_HIGH_DISCOUNT).pack(pady=15)
        
        fields = {}
        labels = ["Название", "Размер", "Цена (₽)", "Остаток (шт)", "Скидка (%)", "Категория", "Эмодзи", "Описание"]
        frame = tk.Frame(dialog, bg=BG_PRIMARY)
        frame.pack(pady=10, padx=30, fill=tk.BOTH, expand=True)
        
        for i, label in enumerate(labels):
            tk.Label(frame, text=label, bg=BG_PRIMARY, font=(FONT_FAMILY, 10), anchor="w").grid(row=i, column=0, padx=10, pady=8, sticky="w")
            entry = tk.Entry(frame, font=(FONT_FAMILY, 10), width=30, relief=tk.GROOVE)
            entry.grid(row=i, column=1, padx=10, pady=8)
            if label == "Эмодзи":
                entry.insert(0, "👟")
            fields[label] = entry
        
        def save():
            try:
                name = fields["Название"].get()
                size = fields["Размер"].get()
                price = float(fields["Цена (₽)"].get())
                stock = int(fields["Остаток (шт)"].get())
                discount = int(fields["Скидка (%)"].get())
                category = fields["Категория"].get()
                emoji = fields["Эмодзи"].get() or "👟"
                desc = fields["Описание"].get()
                if not name or not category:
                    messagebox.showwarning("Внимание", "Заполните название и категорию")
                    return
                add_good(name, size, price, stock, discount, category, emoji, desc)
                self.load_goods()
                dialog.destroy()
                messagebox.showinfo("Успех", f"Товар '{name}' добавлен")
            except ValueError:
                messagebox.showerror("Ошибка", "Проверьте введённые данные (цена и остаток должны быть числами)")
        
        btn_frame = tk.Frame(dialog, bg=BG_PRIMARY)
        btn_frame.pack(pady=20)
        btn_save = tk.Button(btn_frame, text="💾 Сохранить", command=save, bg=BG_ACCENT, font=(FONT_FAMILY, 11, "bold"), relief=tk.FLAT, cursor="hand2", padx=20)
        btn_save.pack(side=tk.LEFT, padx=10)
        btn_cancel = tk.Button(btn_frame, text="✖ Отмена", command=dialog.destroy, bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=20)
        btn_cancel.pack(side=tk.LEFT, padx=10)
    
    def edit_good_dialog(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Внимание", "Выберите товар")
            return
        values = self.tree.item(selected[0])['values']
        good_id = values[0]
        good = get_good_by_id(good_id)
        if not good:
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title("✏️ Редактирование товара")
        dialog.geometry("450x500")
        dialog.configure(bg=BG_PRIMARY)
        dialog.resizable(False, False)
        
        tk.Label(dialog, text="✏️ Редактирование товара", font=(FONT_FAMILY, 16, "bold"), bg=BG_PRIMARY, fg=BG_HIGH_DISCOUNT).pack(pady=15)
        
        fields = {}
        labels = ["Название", "Размер", "Цена (₽)", "Остаток (шт)", "Скидка (%)", "Категория", "Эмодзи", "Описание"]
        defaults = [good[1], good[2], good[3], good[4], good[5], good[6], good[7] or "👟", good[8] or ""]
        
        frame = tk.Frame(dialog, bg=BG_PRIMARY)
        frame.pack(pady=10, padx=30, fill=tk.BOTH, expand=True)
        
        for i, (label, default) in enumerate(zip(labels, defaults)):
            tk.Label(frame, text=label, bg=BG_PRIMARY, font=(FONT_FAMILY, 10), anchor="w").grid(row=i, column=0, padx=10, pady=8, sticky="w")
            entry = tk.Entry(frame, font=(FONT_FAMILY, 10), width=30, relief=tk.GROOVE)
            entry.insert(0, str(default))
            entry.grid(row=i, column=1, padx=10, pady=8)
            fields[label] = entry
        
        def save():
            try:
                name = fields["Название"].get()
                size = fields["Размер"].get()
                price = float(fields["Цена (₽)"].get())
                stock = int(fields["Остаток (шт)"].get())
                discount = int(fields["Скидка (%)"].get())
                category = fields["Категория"].get()
                emoji = fields["Эмодзи"].get() or "👟"
                desc = fields["Описание"].get()
                update_good(good_id, name, size, price, stock, discount, category, emoji, desc)
                self.load_goods()
                dialog.destroy()
                messagebox.showinfo("Успех", "Товар обновлён")
            except ValueError:
                messagebox.showerror("Ошибка", "Проверьте введённые данные")
        
        btn_frame = tk.Frame(dialog, bg=BG_PRIMARY)
        btn_frame.pack(pady=20)
        btn_save = tk.Button(btn_frame, text="💾 Сохранить", command=save, bg=BG_ACCENT, font=(FONT_FAMILY, 11, "bold"), relief=tk.FLAT, cursor="hand2", padx=20)
        btn_save.pack(side=tk.LEFT, padx=10)
        btn_cancel = tk.Button(btn_frame, text="✖ Отмена", command=dialog.destroy, bg=BG_SECONDARY, relief=tk.FLAT, cursor="hand2", padx=20)
        btn_cancel.pack(side=tk.LEFT, padx=10)
    
    def delete_good(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Внимание", "Выберите товар")
            return
        values = self.tree.item(selected[0])['values']
        if messagebox.askyesno("Подтверждение", f"Удалить товар '{values[1]}'?"):
            good_id = values[0]
            delete_good(good_id)
            self.load_goods()
            messagebox.showinfo("Успех", "Товар удалён")
    
    def show_orders(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        self.highlight_nav(self.nav_btn_orders)
        
        header = tk.Frame(self.content_frame, bg=BG_PRIMARY, relief=tk.RAISED)
        header.pack(fill=tk.X, pady=(0, 15))
        tk.Label(header, text="📋 Управление заказами", font=(FONT_FAMILY, 18, "bold"), bg=BG_PRIMARY, fg=BG_HIGH_DISCOUNT).pack(side=tk.LEFT, padx=20, pady=15)
        
        columns = ("№", "Покупатель", "Дата", "Сумма", "Статус", "Адрес", "Оплата")
        self.orders_tree = ttk.Treeview(self.content_frame, columns=columns, show="headings", height=20)
        for col in columns:
            self.orders_tree.heading(col, text=col)
            self.orders_tree.column(col, width=120)
        self.orders_tree.pack(fill=tk.BOTH, expand=True, pady=10)
        
        btn_frame = tk.Frame(self.content_frame, bg=BG_SECONDARY)
        btn_frame.pack(pady=10)
        
        tk.Label(btn_frame, text="Новый статус:", bg=BG_SECONDARY, font=(FONT_FAMILY, 10)).pack(side=tk.LEFT, padx=5)
        self.status_var = tk.StringVar(value="new")
        status_combo = ttk.Combobox(btn_frame, textvariable=self.status_var,
                                    values=["new", "paid", "processing", "shipped", "delivered", "cancelled"],
                                    width=14)
        status_combo.pack(side=tk.LEFT, padx=5)
        btn_update = tk.Button(btn_frame, text="🔄 Обновить статус", command=self.update_order_status,
                               bg=BG_ACCENT, relief=tk.FLAT, cursor="hand2", padx=15)
        btn_update.pack(side=tk.LEFT, padx=10)
        
        self.load_orders_admin()
    
    def load_orders_admin(self):
        for row in self.orders_tree.get_children():
            self.orders_tree.delete(row)
        orders = get_orders(role="admin")
        for order in orders:
            self.orders_tree.insert("", tk.END, values=order)
    
    def update_order_status(self):
        selected = self.orders_tree.selection()
        if not selected:
            messagebox.showwarning("Внимание", "Выберите заказ")
            return
        order_id = self.orders_tree.item(selected[0])['values'][0]
        new_status = self.status_var.get()
        update_order_status(order_id, new_status)
        self.load_orders_admin()
        messagebox.showinfo("Успех", f"Статус заказа №{order_id} обновлён")
    
    def logout(self):
        if messagebox.askyesno("Выход", "Вы уверены?"):
            self.root.destroy()
            root = tk.Tk()
            LoginWindow(root)
            root.mainloop()

# ==================== ЗАПУСК ====================
if __name__ == "__main__":
    init_db()
    root = tk.Tk()
    app = LoginWindow(root)
    root.mainloop()